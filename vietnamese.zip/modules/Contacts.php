<?php
/*+***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 *************************************************************************************/
$languageStrings = array(
	// Basic Strings
	'Contacts' => 'Contacts',
	'SINGLE_Contacts' => 'Địa chỉ liên hệ',
	'LBL_ADD_RECORD' => 'Thêm liên hệ',
	'LBL_RECORDS_LIST' => 'Danh bạ',

	// Blocks
	'LBL_CONTACT_INFORMATION' => 'Thông tin cơ bản',
	'LBL_CUSTOMER_PORTAL_INFORMATION' => 'Cổng thông tin khách hàng',
	'LBL_IMAGE_INFORMATION' => 'ảnh đại diện',
	'LBL_COPY_OTHER_ADDRESS' => 'Sao chép địa chỉ khác',
	'LBL_COPY_MAILING_ADDRESS' => 'Sao chép địa chỉ mail khác',

	//Field Labels
	'Office Phone' => 'Số điện thoại văn phòng',
	'Home Phone' => 'Số điện thoại nhà',
	'Title' => 'Tiêu đề',
	'Department' => 'Bộ phận',
	'Birthdate' => 'Ngày sinh',
	'Reports To' => 'Báo cáo tới',
	'Assistant' => 'Trợ lý',
	'Assistant Phone' => 'Số điện thoại của trợ lý',
	'Do Not Call' => 'Không gọi',
	'Reference' => 'Tham khảo',
	'Portal User' => 'Portal User',
	'Mailing Street' => 'Đường',
	'Mailing City' => 'Thành phố',
	'Mailing State' => 'Bang',
	'Mailing Zip' => 'Mailing Zip',
	'Mailing Country' => 'Quốc gia',
	'Mailing PO Box' => 'Mailing P.O. Box',
	'Other Street' => 'Đường khác',
	'Other City' => 'Thành phố khác',
	'Other State' => 'Bang khác',
	'Other Zip' => 'Other Zip',
	'Other Country' => 'Quốc gia khác',
	'Other PO Box' => 'Other P.O. Box',
	'Contact Image' => 'Hình ảnh liên lạc',
	'Other Phone' => 'Số điện thoại phụ',
	'Email' => 'Email chính',
	'Secondary Email' => 'Email phụ',
	'Contact Id' => 'Contact Id',
	
	//Added for Picklist Values
	'Mr.'=>'Ông',
	'Ms.'=>'Ms.',
	'Mrs.'=>'Bà.',
	'Dr.'=>'Dr.',
	'Prof.'=>'Prof.',
	
	'User List'=>'Đanh sách user',
);

$jsLanguageStrings = array(
        'LBL_SYNC_BUTTON' => 'Đồng bộ hóa ngay',
        'LBL_SYNCRONIZING' => 'Đang đồng bộ....',
        'LBL_NOT_SYNCRONIZED' => 'Bạn chưa đồng bộ',
        'LBL_FIELD_MAPPING' => 'Field Mapping'
 );